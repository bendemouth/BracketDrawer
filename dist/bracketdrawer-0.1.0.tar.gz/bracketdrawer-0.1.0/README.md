# BracketDrawer
 A Python Package to easily create tournament brackets.

 I was working on a project where I needed to create tournament brackets for a client, and I could never find a package that really did exactly what I was looking for. So I made my own.

 Some of this code is still specific to what I was working on, but I will continue to work on updating it to make it more flexible and add documentation to explain how to use it. 

 If you have suggestions or would like to contribute, please send me an email at bendemouth@gmail.com.
