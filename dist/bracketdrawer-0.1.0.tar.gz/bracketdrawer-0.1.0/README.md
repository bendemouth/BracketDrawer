# BracketDrawer
 A Python Package to easily create tournament brackets
